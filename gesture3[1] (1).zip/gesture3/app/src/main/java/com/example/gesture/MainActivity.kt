package com.example.gesture

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs

class MainActivity : AppCompatActivity(), GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener {

    private lateinit var gestureDetector: GestureDetector
    private lateinit var button: Button
    private var x2: Float = 0.0f
    private var x1: Float = 0.0f
    private var y2: Float = 0.0f
    private var y1: Float = 0.0f
    private var pressTime: Long = 0

    companion object {
        const val MIN_DISTANCE = 100
        const val HOLD_THRESHOLD = 1000 // Time threshold for a hold action in milliseconds (1 second)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        gestureDetector = GestureDetector(this, this)
        gestureDetector.setOnDoubleTapListener(this)

        button = findViewById(R.id.button)

        button.setOnTouchListener { _, event ->
            if (event != null) {
                gestureDetector.onTouchEvent(event)
            }

            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    x1 = event.x
                    y1 = event.y
                    pressTime = System.currentTimeMillis()
                }

                MotionEvent.ACTION_UP -> {
                    x2 = event.x
                    y2 = event.y

                    val valueX: Float = x2 - x1
                    val valueY: Float = y2 - y1

                    if (System.currentTimeMillis() - pressTime >= HOLD_THRESHOLD) {
                        // Hold action detected
                        button.setBackgroundColor(Color.GREEN)
                        Toast.makeText(this, "Hold", Toast.LENGTH_SHORT).show()
                    } else {
                        // Swipe action detected
                        if (abs(valueX) > MIN_DISTANCE) {
                            if (x2 > x1) {
                                button.setBackgroundColor(Color.BLUE)
                                Toast.makeText(this, "Right swipe", Toast.LENGTH_SHORT).show()
                            } else {
                                button.setBackgroundColor(Color.RED)
                                Toast.makeText(this, "Left swipe", Toast.LENGTH_SHORT).show()
                            }
                        } else if (abs(valueY) > MIN_DISTANCE) {
                            if (y2 > y1) {
                                button.setBackgroundColor(Color.YELLOW)
                                Toast.makeText(this, "Bottom Swipe", Toast.LENGTH_SHORT).show()
                            } else {
                                button.setBackgroundColor(Color.MAGENTA)
                                Toast.makeText(this, "Top Swipe", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }

                MotionEvent.ACTION_CANCEL -> {
                    // Handle action cancel if needed
                }
            }

            true
        }
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        return event?.let { gestureDetector.onTouchEvent(it) } == true || super.onTouchEvent(event)
    }

    override fun onDown(e: MotionEvent): Boolean {
        return true
    }

    override fun onShowPress(e: MotionEvent) {}

    override fun onSingleTapUp(e: MotionEvent): Boolean {
        return false
    }

    override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
        return false
    }

    override fun onLongPress(e: MotionEvent) {}

    override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
        return false
    }

    override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
        return false
    }

    override fun onDoubleTap(e: MotionEvent): Boolean {
        button.setBackgroundColor(Color.CYAN)
        Toast.makeText(this, "Double tap", Toast.LENGTH_SHORT).show()
        return true
    }

    override fun onDoubleTapEvent(e: MotionEvent): Boolean {
        return false
    }
}
